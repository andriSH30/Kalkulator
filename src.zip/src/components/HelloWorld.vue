<template>
  <div class="hello">
    <!-- <h3>{{msg}}</h3> -->
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: Float64Array,
    
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
